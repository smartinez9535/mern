import './App.css';
import UserForm from './components/UserForm';

function App() {
  return (
    <div className="App">
      <h1>app.js</h1>
      {/* <Counter/> */}
      <UserForm/>
    </div>
  );
}

export default App;
