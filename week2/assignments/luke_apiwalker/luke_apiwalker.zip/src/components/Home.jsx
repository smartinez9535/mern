import React from 'react'

const Home = (props) => {
    return (
        <fieldset>
            <legend>Home.jsx</legend>
            <h1>Welcome</h1>
        </fieldset>
    )
}

export default Home