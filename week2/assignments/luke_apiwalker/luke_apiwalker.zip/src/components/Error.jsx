import React from 'react'

const About = (props) => {

    return (
        <fieldset>
            <legend>Error.jsx</legend>
                <h1>These aren't the droids you're looking for</h1>
                <img src="/obi-wan.jpg" alt="obi-wan kenobi" />
        </fieldset>
    )
}

export default About